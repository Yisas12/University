#!/bin/bash

#Copie dos ficheros de texto que ocupen más de un bloque (por ejemplo fuseLib.c y
#myFS.h) a nuestro SF y a un directorio temporal, por ejemplo ./temp
echo "Creando carpeta termporal ./tmp ..."
rm -Rf temp
mkdir temp

echo "Copiando fuseLib.c y myFS.h a ./temp y ./mount-point ..."
cp src/fuseLib.c mount-point/fuseLib.c
cp src/fuseLib.c temp/fuseLib.c

cp src/myFS.h mount-point/myFS.h
cp src/myFS.h temp/myFS.h

echo "Mostrando diferencias del primer fichero fuseLib.c:"
if diff temp/fuseLib.c mount-point/fuseLib.c
then echo "[IGUALES]"
else echo "[DIFERENTES]"
fi

echo "Modificamos el tamaño de fuseLib.c en ./mountpoint y ./tmp"
truncate mount-point/fuseLib.c -s -1
truncate temp/fuseLib.c -s -1
echo "Mostrando diferencias del primer fichero fuseLib.c:"
if diff temp/fuseLib.c mount-point/fuseLib.c
then echo "[IGUALES]"
else echo "[DIFERENTES]"
fi

echo "Copiamos un tercer fichero de texto test/file1.txt"
cp test/file1.txt mount-point/file1.txt

echo "Mostrando diferencias del tercer fichero file1.txt:"
if diff test/file1.txt mount-point/file1.txt
then echo "[IGUALES]"
else echo "[DIFERENTES]"
fi

echo "Modificamos el tamaño del segundo en ./mount-point y ./tmp"
truncate mount-point/myFS.h -s +5
truncate temp/myFS.h -s +5

echo "Mostrando diferencias del segundo fichero myFS.h:"
if diff temp/myFS.h mount-point/myFS.h
then echo "[IGUALES]"
else echo "[DIFERENTES]"
fi

echo "Creando carpeta con mkdir"
ls -la mount-point
